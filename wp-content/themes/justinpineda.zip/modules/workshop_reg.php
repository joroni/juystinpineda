<?php

/* Workshop Reg */
?>
<!--<select id='options'></select>


<div id='cn'>
  
</div>
<script
  src="http://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>-->



<script>
  
  
  $.getJSON( "http://178.128.63.151/justinpineda2/wp-json/wp/v2/workshops?_embed", function( data ) {
 
   for(var a =0; a <= data.length -1; a++){
     var title  = data[a].title['rendered'];
     var id  = data[a].id;
     $('#wpforms-2100-field_5').append("<option value="+id+">"+title+"</option>");
   } 
    
    
 
 }); 
  
  
  

</script>
